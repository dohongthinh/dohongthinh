package com.example.a.comp304_mobiledevelopment_assignment4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class WelcomeAdminActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_admin);
        Intent intent = getIntent();
        String adminFullName = intent.getStringExtra("adminFullName");

        TextView tv = (TextView) findViewById(R.id.adminFullNameTV);
        tv.setText(adminFullName);
    }

    public void viewBookings(View view) {
        Intent intent = new Intent(this, BookingListActivity.class);
        startActivity(intent);
    }

    public void viewAudiences(View view) {
        Intent intent = new Intent(this, AudienceListActivity.class);
        startActivity(intent);
    }
}
