package com.example.a.comp304_mobiledevelopment_assignment4;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class AudienceLogInActivity extends AppCompatActivity {

    //private field
    private DatabaseManager dbManger= null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audience_log_in);

    }

    //methods provide log in
    public void Login(View view) {

        dbManger = new DatabaseManager(this);

        TextView txtUsername = findViewById(R.id.AuLogUsernameTextField);
        String username = txtUsername.getText().toString();

        TextView txtUserpassword = findViewById(R.id.AuLogPasswordTextField);
        String userpassword = txtUserpassword.getText().toString();

        //share pref

        if(dbManger.verifyAudienceLogin(username, userpassword))
        {
            SharedPreferences myPreference = getSharedPreferences("AudienceUserName", MODE_PRIVATE);
            SharedPreferences.Editor prefEditor = myPreference.edit();
            prefEditor.putString("UserName", username);
            prefEditor.commit();

            Intent intent = new Intent(this, WelcomeAudienceActivity.class);
            startActivity(intent);
        }

        else    //invalid log in
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Login failed").setMessage("Invalid audience")
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    }).show();
        }
        dbManger.close();
    }

    public void goToRegistration(View view) {
        Intent intent = new Intent(this, AudienceRegistrationActivity.class);
        startActivity(intent);
    }
}
