package com.example.a.comp304_mobiledevelopment_assignment4;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class AdminLogInActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_log_in);

    }

    public void loginAdmin(View view) {
        EditText adminIdET = (EditText) findViewById(R.id.adminUsernameET);
        EditText adminPwdET = (EditText) findViewById(R.id.adminPasswordET);

        String adminId = adminIdET.getText().toString();
        String adminPwd = adminPwdET.getText().toString();

        DatabaseManager db = new DatabaseManager(this);

        //db.getTableLog("admin", "employeeId");
        if (db.AuthenticateAccount("admin", adminId, adminPwd, "userName", "password")) {
            showToast("Log in successfully");

            // Put in shared preferences
            SharedPreferences myPreference = getSharedPreferences("AdminUserName", MODE_PRIVATE);
            SharedPreferences.Editor prefEditor = myPreference.edit();
            prefEditor.putString("userName", adminId);
            prefEditor.commit();

            Intent intent = new Intent(this, WelcomeAdminActivity.class);
            intent.putExtra("adminFullName", db.getFullName("admin", adminId, "userName"));
            startActivity(intent);
        }
        else {
            showToast("Wrong username / id");
        }
    }

    public void showToast(String message) {
        Context context = getApplicationContext();
        CharSequence text = message;
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }
}
