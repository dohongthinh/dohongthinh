package com.example.a.comp304_mobiledevelopment_assignment4;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class WelcomeAudienceActivity extends AppCompatActivity {
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_audience);

        SharedPreferences myPref = getSharedPreferences("AudienceUserName", MODE_PRIVATE);
        String myString = myPref.getString("UserName","");
        name = myString;
        TextView auNameTxt = findViewById(R.id.auNameTxt);
        auNameTxt.setText(myString);


    }

    public void viewAudienceDetail(View view) {
        SharedPreferences myP = getSharedPreferences("AuUserName", MODE_PRIVATE);
        SharedPreferences.Editor prefE = myP.edit();
        prefE.putString("username", name);
        prefE.commit();
        Intent intent = new Intent(this, DisplayAudienceDetailActivity.class);
        startActivity(intent);
    }

    public void viewBookingDetail(View view) {
        Intent intent = new Intent(this, BookingDetailActivity.class);
        startActivity(intent);
    }
}
