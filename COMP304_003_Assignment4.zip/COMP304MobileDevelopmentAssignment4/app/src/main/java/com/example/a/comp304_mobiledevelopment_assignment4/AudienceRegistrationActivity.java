package com.example.a.comp304_mobiledevelopment_assignment4;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class AudienceRegistrationActivity extends AppCompatActivity {
    private static final String[] audienceTableFields = {"emailId", "userName", "password", "firstName", "lastName" ,"address","city","postalCode"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audience_registration);
    }
    //registration
    public void registration(View view) {
        //fields
        Intent intent = new Intent(this, WelcomeAudienceActivity.class);
        //get information
        TextView txtEmailId = findViewById(R.id.textidTxt);
        String EmailId= txtEmailId.getText().toString();
        TextView txtUsername = findViewById(R.id.usernameTxt);
        String Username= txtUsername.getText().toString();
        TextView txtPassword =  findViewById(R.id.passwordTxt);
        String Password= txtPassword.getText().toString();
        TextView txtFirstName =  findViewById(R.id.firstnameTxt);
        String FirstName= txtFirstName.getText().toString();
        TextView txtLastName=  findViewById(R.id.lastnameTxt);
        String LastName= txtLastName.getText().toString();
        TextView txtAddress =  findViewById(R.id.addressTxt);
        String Address= txtAddress.getText().toString();
        TextView txtCity =  findViewById(R.id.cityTxt);
        String City= txtCity.getText().toString();
        TextView txtPostalCode =  findViewById(R.id.postalcodeTxt);
        String PostalCode= txtPostalCode.getText().toString();

        final String record[] = {EmailId,Username,Password,FirstName,LastName,Address,City,PostalCode};
        DatabaseManager db = new DatabaseManager(this);
        ContentValues values = new ContentValues();
        db.addRecord(values,"audience",audienceTableFields,record);
        //shared preferences
        //String username = txtUsername.getText().toString();
        SharedPreferences myP = getSharedPreferences("AudienceUserName", MODE_PRIVATE);
        SharedPreferences.Editor prefE = myP.edit();
        prefE.putString("UserName", Username);
        prefE.commit();

        startActivity(intent);

    }


}
