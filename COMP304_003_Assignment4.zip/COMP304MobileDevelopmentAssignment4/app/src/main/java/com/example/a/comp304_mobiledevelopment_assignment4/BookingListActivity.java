package com.example.a.comp304_mobiledevelopment_assignment4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class BookingListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_list);

        DatabaseManager db = new DatabaseManager(this);
        LinearLayout ll = (LinearLayout)findViewById(R.id.bookinglistLinear);
        String[] bookinglist = db.getListOfBookings();
        for (int i=0; i<bookinglist.length; i++) {
            if (bookinglist[i] != "" || bookinglist[i] != null || !bookinglist[i].equals("")) {
                //final String fisrtAndLastName = bookinglist[i];
                final Button myButton = new Button(this);
                myButton.setText(bookinglist[i]);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );
                myButton.setMinWidth(5000);
                myButton.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                myButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(BookingListActivity.this, BookingDetailActivity.class);
                        //String[] first_last = fisrtAndLastName.split("\\s+");
                        //intent.putExtra("firstName", first_last[0]);
                        //intent.putExtra("lastName", first_last[1]);
                        startActivity(intent);
                    }
                });
                ll.addView(myButton, p);
            }
        }
    }
}
