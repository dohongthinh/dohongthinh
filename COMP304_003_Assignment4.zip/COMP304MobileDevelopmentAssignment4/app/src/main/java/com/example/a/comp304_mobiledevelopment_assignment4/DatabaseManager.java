package com.example.a.comp304_mobiledevelopment_assignment4;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.ContactsContract;
import android.util.Log;

public class DatabaseManager extends SQLiteOpenHelper {
    //
    private static final String DATABASE_NAME = "lab4";
    private static final int DATABASE_VERSION = 1;
    //
    private String tables[]; //table names
    private String tableCreatorString[]; //SQL statements to create tables
    // private field
    private SQLiteDatabase db = null;
    //class constructor
    public DatabaseManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

        db = this.getWritableDatabase();
    }


    //initialize database table names and DDL statements
    public void dbInitialize(String[] tables, String tableCreatorString[])
    {
        this.tables=tables;
        this.tableCreatorString=tableCreatorString;
    }

    // Create tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Drop existing tables
        for (int i=0;i<tables.length;i++)
            db.execSQL("DROP TABLE IF EXISTS " + tables[i]);
        //create them
        for (int i=0;i<tables.length;i++)
            db.execSQL(tableCreatorString[i]);

    }
    //create the database
    /*
    public void createDatabase(Context context)
    {
        SQLiteDatabase mDatabase;
        mDatabase = context.openOrCreateDatabase(
                DATABASE_NAME,
                SQLiteDatabase.CREATE_IF_NECESSARY,
                null);

    }
    */
    //delete the database
    public void deleteDatabase(Context context)
    {
        context.deleteDatabase(DATABASE_NAME);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables
        for (int i=0;i<tables.length;i++)
            db.execSQL("DROP TABLE IF EXISTS " + tables[i]);

        // Create tables again
        onCreate(db);
    }
    /////////////////////////
    // Database operations
    /////////////////////////
    // Add a new record
    void addRecord(ContentValues values, String tableName, String fields[],String record[]) {
        SQLiteDatabase db = this.getWritableDatabase();

        for (int i=1;i<record.length;i++)
            values.put(fields[i], record[i]);
        // Insert the row
        db.insert(tableName, null, values);
        db.close(); //close database connection
    }


    // Authenticate Record
    public boolean AuthenticateAccount(String tableName, String logInId, String password, String idColName, String pwdColName) {
        boolean result = false;
        String selectQuery = "SELECT " +  pwdColName + " FROM " + tableName + " WHERE " + idColName + " = " + "'" + logInId + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        Log.i("query", selectQuery);
        if (cursor.getCount() == 0 || cursor.getCount() > 1 || !cursor.moveToFirst()) {
            Log.i("notFound", "Record not found");
            result = false;
        }
        else {
            String pwd = cursor.getString(cursor.getColumnIndex(pwdColName));
            Log.i("pwd", pwd + " | " + password);
            if (pwd.equals(password)) {
                Log.i("TRUE", "Password match");
                result = true;
            }
            else {
                Log.i("FALSE", "Password doesn't match");
                result = false;
            }
        }
        return result;
    }


    public String getFullName(String tableName, String id, String colId) {
        String fullName = "n/a";
        String selectQuery = "SELECT * FROM " + tableName + " WHERE " + colId + " = " + "'" + id + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst() && cursor.getCount() == 1) {
            fullName = cursor.getString(cursor.getColumnIndex("firstName")) + " " + cursor.getString(cursor.getColumnIndex("lastName"));
        }
        Log.i("fullname", fullName);
        return fullName;
    }

    // Read all records
    public List getTable(String tableName) {
        List table = new ArrayList(); //to store all rows
        // Select all records
        String selectQuery = "SELECT  * FROM " + tableName;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        ArrayList row=new ArrayList(); //to store one row
        //scroll over rows and store each row in an array list object
        if (cursor.moveToFirst())
        {
            do
            { // for each row
                for (int i = 0; i < cursor.getColumnCount(); i++) {
                    row.add(cursor.getString(i));
                }

                table.add(row); //add row to the list

            } while (cursor.moveToNext());
        }

        // return table as a list
        return table;
    }

    public void getTableLog(String tableName, String columnName) {
        String selectQuery = "SELECT  * FROM " + tableName;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        //scroll over rows and store each row in an array list object
        if (cursor.moveToFirst())
        {
            do
            { // for each row
                for (int i = 0; i < cursor.getColumnCount(); i++) {
                    Log.i(">>>>>>>>>>>>>> Account", cursor.getString(cursor.getColumnIndex(columnName)));
                }
            } while (cursor.moveToNext());
        }

    }

    public String[] getListOfAudience() {
        String selectQuery = "SELECT  * FROM " + "audience";
        String[] result = new String[1000];
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            int i = 0;
            do
            { // for each row
                result[i] = cursor.getString(cursor.getColumnIndex("firstName")) + " " + cursor.getString(cursor.getColumnIndex("lastName"));
                i++;
            } while (cursor.moveToNext());
        }
        return result;
    }

    public String[] viewAudienceDetail(String firstName, String lastName) {
        String selectQuery = "SELECT  * FROM " + "audience WHERE firstName = " + "'" + firstName + "'" + " AND lastName = " + "'" + lastName + "'";
        String[] result = new String[1000];
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            for (int i = 0; i < cursor.getColumnCount(); i++) {
                result[i] = cursor.getString(i);
            }
        }
        return result;
    }
    // Update a record
    public int updateRecord(ContentValues values, String tableName, String fields[],String record[]) {
        SQLiteDatabase db = this.getWritableDatabase();

        for (int i=1;i<record.length;i++)
            values.put(fields[i], record[i]);

        // updating row with given id = record[0]
        return db.update(tableName, values, fields[0] + " = ?",
                new String[] { record[0] });
    }

    // Delete a record with a given id
    public void deleteRecord(String tableName, String idName, String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(tableName, idName + " = ?",
                new String[] { id });
        db.close();
    }

    //verify audience login
    public boolean verifyAudienceLogin(String username, String userpassword) {
        String query;
        String[] arguments;

            query = "SELECT emailId FROM audience WHERE userName = ? AND password = ?";
            arguments = new String[]{username, userpassword};

        Cursor cursor = db.rawQuery(query, arguments);
        boolean result;
        if (1 == cursor.getCount())
        {
            result = true;
        }
        else
        {
            result = false;
        }
        cursor.close();
        return result;
    }

        //get one row of audience data
        public Cursor getAudienceDataDetail(String userName){
            SQLiteDatabase db = this.getReadableDatabase();

            String query;
            String[] arguments;

            query = "SELECT emailId,userName,password,firstName,lastName,address,city,postalCode FROM Audience WHERE userName = ?";
            arguments = new String[]{userName};
            Cursor resource = db.rawQuery(query,arguments);
            return resource;
        }

    public String getMovieName(String movieId) {
        String movieName = "n/a";
        String selectQuery = "SELECT * FROM Movies WHERE movieId  = " + "'" + movieId + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst() && cursor.getCount() == 1) {
            movieName = cursor.getString(cursor.getColumnIndex("movieName"));
        }
        // Log.i("fullname", fullName);
        return movieName;
    }

    public String[] getListOfBookings() {
        String selectQuery = "SELECT  * FROM " + "booking";
        String[] result = new String[1000];
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            int i = 0;
            do
            { // for each row
                String emailId = cursor.getString(cursor.getColumnIndex("emailId"));
                String movieId = cursor.getString(cursor.getColumnIndex("movieId"));
                // Get bookingId => get name + movieName
                String fullName = this.getFullName("audience", emailId, "emailId");
                String movieName = this.getMovieName(movieId);
                result[i] = movieName + " " + fullName;
                i++;
            } while (cursor.moveToNext());
        }
        return result;
    }


}
