package com.example.a.comp304_mobiledevelopment_assignment4;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.AlertDialog;
import android.widget.TextView;

public class DisplayAudienceDetailActivity extends AppCompatActivity {
    DatabaseManager myDb = new DatabaseManager(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_audience_detail);
        //get userName
        SharedPreferences aPref = getSharedPreferences("AuUserName", MODE_PRIVATE);
        String myString = aPref.getString("username","");
        //get data from audience row
        Cursor res = myDb.getAudienceDataDetail(myString);

        StringBuilder result = new StringBuilder();
        while (res.moveToNext()) {
            result.append("Email Id :"+ res.getString(res.getColumnIndex("emailId"))+"\n");
            result.append("Username :"+ res.getString(res.getColumnIndex("userName"))+"\n");
            result.append("Password :"+ res.getString(res.getColumnIndex("password"))+"\n");
            result.append("First name :"+ res.getString(res.getColumnIndex("firstName"))+"\n");
            result.append("Last name :"+ res.getString(res.getColumnIndex("lastName"))+"\n");
            result.append("Address :"+ res.getString(res.getColumnIndex("address"))+"\n");
            result.append("City :"+ res.getString(res.getColumnIndex("city"))+"\n");
            result.append("PostalCode :"+ res.getString(res.getColumnIndex("postalCode"))+"\n");

        }
        TextView ShowData = findViewById(R.id.AuInforTxt);
        ShowData.setText(result.toString());
        // Show all data
        //showMessage("Data",buffer.toString());
    }

}
