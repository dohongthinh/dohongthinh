package com.example.a.comp304_mobiledevelopment_assignment4;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private static final String tables[]={"admin","audience","booking","movies"};
    //
    private static final String[] adminTableFields = {"employeeId", "userName", "password", "firstName", "lastName" };
    private static final String[] audienceTableFields = {"emailId", "userName", "password", "firstName", "lastName" ,"address","city","postalCode"};
    private static final String[] movieTableFields = {"movieId", "movieName", "director", "genre"};
    private static final String[] bookingTableFields = {"emailId", "bookingId", "movieId", "paymentDate", "amountPaid", "showDate", "showTime"};
    private static final String[] adminRecord1 = {"001", "kien47", "kien123", "Kien", "Ngo"};
    private static final String[] adminRecord2 = {"002", "thinh1", "thinh123", "Thinh", "Do"};
    private static final String[] audienceRecord1 = {"001", "timmy", "thinh999", "Thinh", "Do","Toronto","ON","M1B4M5"};
    private static final String[] audienceRecord2 = {"002", "perseus", "perseus999", "Percy", "Jackson","Toronto","ON","M1B4M5"};
    private static final String[] movieRecord1 = {"001", "Bumblebee", "Bay", "action"};
    private static final String[] movieRecord2 = {"002", "Optimus", "Tim", "drama"};
    private static final String[] bookingRecord1 = {"001", "b001", "001", "10-04-2018", "35", "11-04-2018",  "8:20pm"};
    private static final String[] bookingRecord2 = {"002", "b002", "002", "10-05-2018", "65", "11-05-2018",  "18:20pm"};

    private static final String tableCreatorString[] =
            {"CREATE TABLE  Admin  (\n" +
                    "\t employeeId \tTEXT,\n" +
                    "\t userName \tTEXT,\n" +
                    "\t password \tTEXT,\n" +
                    "\t firstName \tTEXT,\n" +
                    "\t lastName \tTEXT,\n" +
                    "\tPRIMARY KEY( employeeId )\n" +
                    ");",
            "CREATE TABLE  Audience  (\n" +
                    "\t emailId \tTEXT,\n" +
                    "\t userName \tTEXT,\n" +
                    "\t password \tTEXT,\n" +
                    "\t firstName \tTEXT,\n" +
                    "\t lastName \tTEXT,\n" +
                    "\t address \tTEXT,\n" +
                    "\t city \tTEXT,\n" +
                    "\t postalCode \tINTEGER,\n" +
                    "\tPRIMARY KEY( emailId )\n" +
                    ");",
            "CREATE TABLE  Booking  (\n" +
                    "\t emailId \tTEXT NOT NULL,\n" +
                    "\t bookingId \tTEXT NOT NULL,\n" +
                    "\t movieId \tTEXT NOT NULL,\n" +
                    "\t paymentDate \tTEXT NOT NULL,\n" +
                    "\t amountPaid \tNUMERIC NOT NULL,\n" +
                    "\t showDate \tTEXT NOT NULL,\n" +
                    "\t showTime \tTEXT NOT NULL,\n" +
                    "\t bookingStatus \tTEXT NOT NULL,\n" +
                    "\tPRIMARY KEY( bookingId ),\n" +
                    //"\tFOREIGN KEY( emailId ) REFERENCES  Audience ( emailId ) \n" +
                    //"\tFOREIGN KEY( movieId ) REFERENCES  Movies ( movieId )\n" +
                    ");",

            "CREATE TABLE  Movies  (\n" +
                    "\t movieId \tTEXT NOT NULL,\n" +
                    "\t movieName \tTEXT NOT NULL,\n" +
                    "\t director \tTEXT NOT NULL,\n" +
                    "\t genre \tTEXT NOT NULL,\n" +
                    "\tPRIMARY KEY( movieId )\n" +
                    ");" };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final DatabaseManager db = new DatabaseManager(getApplicationContext());
        db.dbInitialize( tables,tableCreatorString);

        ContentValues values = new ContentValues();
        // admins
        db.addRecord(values, "admin", adminTableFields, adminRecord1);
        db.addRecord(values, "admin", adminTableFields, adminRecord2);
        // audiences
        db.addRecord(values, "audience", audienceTableFields, audienceRecord1);
        db.addRecord(values, "audience", audienceTableFields, audienceRecord2);
        // movies
        db.addRecord(values, "movies", movieTableFields, movieRecord1);
        db.addRecord(values, "movies", movieTableFields, movieRecord2);
        // bookings
        db.addRecord(values, "booking", bookingTableFields, bookingRecord1);
        db.addRecord(values, "booking", bookingTableFields, bookingRecord2);
    }

    public void logInAsAdmin(View view) {
        Intent intent = new Intent(this, AdminLogInActivity.class);
        startActivity(intent);
    }

    public void logInAsAudience(View view) {
        Intent intent = new Intent(this, AudienceLogInActivity.class);
        startActivity(intent);
    }
}
