package com.example.a.comp304_mobiledevelopment_assignment4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AudienceDetailActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audience_detail);

        Intent intent = getIntent();

        String firstName = intent.getStringExtra("firstName");
        String lastName = intent.getStringExtra("lastName");

        DatabaseManager db = new DatabaseManager(this);
        LinearLayout ll = (LinearLayout)findViewById(R.id.audienceDetailLV);
        String[] audienceDetail = db.viewAudienceDetail(firstName, lastName);
        for (int i =0; i < audienceDetail.length; i++) {
            if (audienceDetail[i] == "" || audienceDetail[i] == null) audienceDetail[i] = "n/a";
        }

        TextView email = (TextView) findViewById(R.id.detailEmailTV);
        email.setText("Email: " + audienceDetail[0]);
        TextView username = (TextView) findViewById(R.id.detailUsernameTV);
        username.setText("Username: " + audienceDetail[1]);
        TextView _firstName = (TextView) findViewById(R.id.detailFirstNameTV);
        _firstName.setText("First name: " + audienceDetail[3]);
        TextView _lastName = (TextView) findViewById(R.id.detailLastNameTV);
        _lastName.setText("Last name: " + audienceDetail[4]);
        TextView address = (TextView) findViewById(R.id.detailAddressTV);
        address.setText("Address: " + audienceDetail[5]);
        TextView city = (TextView) findViewById(R.id.detailCityTV);
        city.setText("City: " + audienceDetail[6]);
        TextView postalCode = (TextView) findViewById(R.id.detailPostalCodeTV);
        postalCode.setText("Postal code: " + audienceDetail[7]);
    }
}
